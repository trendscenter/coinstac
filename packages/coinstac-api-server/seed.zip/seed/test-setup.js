const { populate } = require('./populate');

populate();
